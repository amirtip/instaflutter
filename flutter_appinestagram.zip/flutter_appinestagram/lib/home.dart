import 'package:flutter/material.dart';
import 'Tabs/add.dart';
import 'Tabs/like.dart';
import 'Tabs/profile.dart';
import 'Tabs/search.dart';
import 'Tabs/homepage.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with SingleTickerProviderStateMixin {
  TabController _tabController;
  static final _ktabpages = <Widget>[
    homepage(),
    search(),
    add(),
    like(),
    profile(),
  ];
  static final _ktabs = <Tab>[
    Tab(
      icon: Icon(
        Icons.home,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.search,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.add,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.favorite,
        color: Colors.black,
      ),
    ),
    Tab(
      icon: Icon(
        Icons.person,
        color: Colors.black,
      ),
    ),
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 5,
      vsync: this,
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      color: Colors.white,
      home: DefaultTabController(
        length: 5,
        child: Builder(
          builder: (BuildContext context) {
            return Scaffold(
              body: TabBarView(
                children: _ktabpages,
                controller: _tabController,
              ),
              bottomNavigationBar: Material(
                color: Colors.white,
                child: TabBar(
                  tabs: _ktabs,
                  controller: _tabController,
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
